<?php
session_start();

$conn = mysqli_connect(
  'localhost',
  'root',
  '',
  'form'
) or die(mysqli_erro($mysqli));

?>
